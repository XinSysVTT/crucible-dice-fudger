/**
 * Dice Fudger
 * Adds a GM-only "Fudge Roll" chat-message context option that lets the GM edit the individual
 * die results of an already-evaluated Roll stored on a ChatMessage, before that message is
 * revealed to the rest of the table.
 *
 * This does NOT re-roll anything and does NOT create a duplicate message. It edits the real
 * Roll data in place and saves it back to the message. Because Foundry (and Crucible) render
 * chat cards live from message.rolls on every render rather than from a frozen snapshot, the
 * corrected numbers simply appear the next time the card is rendered - including the moment you
 * use core Foundry's own "Reveal Message" option.
 *
 * Verified against the Crucible v0.10.1 system source (not just assumed):
 *  - StandardCheck.isSuccess/isCriticalSuccess/isFailure/isCriticalFailure all read `this.total`
 *    live on every access, so skill/save checks (and group checks, which reuse the same getters
 *    per-participant and recompute their aggregate from those getters on every render) pick up
 *    an edited total automatically - no extra step needed beyond fixing `roll._total`.
 *  - AttackRoll is the one case that does NOT work that way: its Hit/Miss/Dodge/etc. label and
 *    its damage total are cached on `roll.data.result` / `roll.data.damage` at the moment the
 *    attack was first resolved, not recomputed from `this.total` on render. Crucible's own code
 *    (module/hooks/talent.mjs, used by its "Loaded Dice" reroll talent) handles this by calling
 *    `roll.resolveDamage(actor, target)` again after mutating dice - so this module does the same
 *    thing for attack rolls, and only falls back to a bare total recompute for everything else.
 *  - For the bare recompute, Crucible's own code also revealed the right tool: Foundry's Roll
 *    class exposes `roll._evaluateTotal()`, its real internal totaling method (Crucible calls it
 *    directly in that same talent hook). That's used here instead of a hand-rolled +/- walker,
 *    so multiplication, parentheses, keep/drop, etc. in other systems' formulas are handled
 *    correctly too. A manual +/- fallback is kept only for the unlikely case of a Foundry version
 *    where that private method doesn't exist.
 *
 * When a macro-armed "next roll" fudge cannot be applied (no DC/threshold data, the dice physically
 * cannot reach the total the requested outcome needs, an unexpected error, or the qualifying roll
 * having been made by another user on their own client so the GM-side interception never ran), the
 * module posts a chat message whispered to every GM user explaining why. Toast notifications are
 * transient and easy to miss mid-session; a GM whisper is persistent and never visible to players.
 */

const MODULE_ID = "crucible-dice-fudger";
let _pendingGroupCheckOutcome = null;
let _pendingGroupCheckParticipantCount = null;
let _riggedParticipantIndex = 0;
const _pendingGroupCheckMessages = new Map();

let _pendingSingleRollOutcome = null;
let _singleRollRiggingInstalled = false;

const OUTCOME_LABELS = {
  criticalSuccess: "Critical Success",
  success: "Success",
  failure: "Failure",
  criticalFailure: "Critical Failure"
};

/**
 * Install a permanent (idempotent) patch on Roll.prototype.evaluate that is a no-op unless a
 * single-roll fudge is currently armed via DiceFudger.armNextRoll(). Unlike _installRollRigging
 * (which wraps/unwraps evaluate for the duration of a single GroupCheck.configure() call), this
 * patch stays installed indefinitely - it just does nothing until _pendingSingleRollOutcome is
 * set, then consumes (clears) that state the moment it successfully intercepts a roll that looks
 * like a Crucible check (has a dc), regardless of whether the edit succeeded, so a bad roll never
 * leaves the module stuck silently rigging every future roll.
 */
function _installSingleRollRigging() {
  if (_singleRollRiggingInstalled) return;
  _singleRollRiggingInstalled = true;
  const originalEvaluate = Roll.prototype.evaluate;
  Roll.prototype.evaluate = async function(...args) {
    const result = await originalEvaluate.apply(this, args);
    const armed = _pendingSingleRollOutcome;
    if (!armed) return result;

    // IMPORTANT: qualification checks (dc data, and actor match if a specific actor was
    // targeted) must happen BEFORE the try/finally below, not inside it. `return` inside a try
    // block still runs its finally clause first - so an early `return result` from inside the
    // try was disarming _pendingSingleRollOutcome on the very first Roll.evaluate() of ANY kind
    // (a damage roll, an NPC's save, another player's check, initiative, etc.), not just on a
    // roll that actually matched. That's why "fudge next roll" often silently did nothing: with
    // more than one person at the table, something else almost always rolls first and ate the
    // arming before the intended roll ever happened.
    if (!_isFudgeableCheckRoll(this)) return result;
    if (armed.actorId) {
      const rollActorId = this.data?.actorId ?? this.options?.data?.actorId ?? null;
      if (rollActorId !== armed.actorId) return result; // not the targeted player - leave armed
    }

    const outcome = armed.outcome;
    try {
      const targetTotal = _chooseGroupOutcomeTotal(this, outcome);
      if (targetTotal === null) {
        console.warn("dice-fudger | roll has no dc/threshold data to force an outcome against - left unmodified.", {outcome, roll: this});
        ui.notifications.warn(`Dice Fudger: couldn't force this roll to ${OUTCOME_LABELS[outcome] ?? outcome} - it has no DC/threshold data. The roll was left unmodified.`);
        _whisperGmFudgeFailure(armed, this, "the roll has no usable DC/threshold data to force the outcome against, so there was nothing to aim the fudge at. The roll was left unmodified.");
        return result;
      }
      const currentTotal = _evaluateRollTotal(this);
      if (currentTotal !== targetTotal) {
        const edit = _assignDiceValuesToMatchTotal(this, targetTotal);
        if (!edit.edited && this._total !== targetTotal) this._total = targetTotal;
        if (edit.edited || typeof this.resolveDamage === "function") await _reresolveRoll(this);
        if (edit.clamped) {
          const requestedLabel = OUTCOME_LABELS[outcome] ?? outcome;
          const bounds = _outcomeBounds(this, outcome);
          const actualBracket = _outcomeBracketForTotal(this, _evaluateRollTotal(this));
          const actualLabel = actualBracket ? OUTCOME_LABELS[actualBracket] : null;
          _whisperGmFudgeFailure(armed, this,
            `the dice on this roll physically can't reach the total ${requestedLabel} requires ` +
            `(needed ${bounds ? `${bounds.min}\u2013${bounds.max}` : `at least ${edit.requestedTotal}`}); ` +
            `the closest achievable total (${edit.achievedTotal}) was used instead.`,
            {detail: actualLabel && actualLabel !== requestedLabel
              ? `The roll now reads as ${actualLabel} rather than the requested ${requestedLabel}.`
              : `The roll still reads as ${requestedLabel}, just at the lower edge of what its dice allow.`}
          );
        }
      }
      console.debug("dice-fudger | rigged next single roll", {outcome, targetTotal, currentTotal, actorId: armed.actorId});
    } catch (err) {
      console.warn("dice-fudger | failed to rig next single roll:", err);
      _whisperGmFudgeFailure(armed, this,
        "an unexpected error occurred while editing the roll's dice - the roll may be partially modified or untouched. Check the roll's card.",
        {detail: String(err?.message ?? err)});
    } finally {
      // Only reached once a roll actually qualified (right shape, right actor) and was
      // attempted - success or not - so this now only fires on the roll we were waiting for.
      _pendingSingleRollOutcome = null;
      _updateArmedIndicator();
    }
    return result;
  };
}

/**
 * Show (or remove) a small fixed on-screen indicator while a single-roll fudge is armed, so the
 * GM always has a visible reminder of what's queued and a one-click way to cancel it.
 */
function _updateArmedIndicator() {
  let el = document.getElementById("dice-fudger-armed-indicator");
  if (!_pendingSingleRollOutcome) {
    el?.remove();
    return;
  }
  const {outcome, actorId} = _pendingSingleRollOutcome;
  const targetName = actorId ? (game.actors?.get(actorId)?.name ?? "unknown actor") : null;
  if (!el) {
    el = document.createElement("div");
    el.id = "dice-fudger-armed-indicator";
    el.className = "dice-fudger-armed-indicator";
    el.addEventListener("click", () => {
      _pendingSingleRollOutcome = null;
      _updateArmedIndicator();
      ui.notifications.info("Dice Fudger: next-roll fudge cancelled.");
    });
    document.body.appendChild(el);
  }
  el.textContent = `🎲 Next ${targetName ? `${targetName} roll` : "roll"} forced: ${OUTCOME_LABELS[outcome] ?? outcome} (click to cancel)`;
}

/**
 * Post a chat message whispered to every GM user. The roll rigging only exists on the GM's client,
 * and toast notifications are transient - if a fudge fires (or fails) mid-combat while the GM is
 * looking elsewhere, the reason would be lost. A GM whisper is persistent, and whispered messages
 * never appear in a player's chat log at all, so it stays private. Best-effort: never throws, so a
 * messaging failure can't break the fudge flow itself.
 * @param {string[]} lines  HTML lines to render inside the note
 */
function _postGmWhisper(lines) {
  try {
    const gmIds = game.users?.filter((u) => u.isGM).map((u) => u.id) ?? [];
    if (!gmIds.length) return;
    const content = lines.map((line) => `<p style="margin: 0.2em 0;">${line}</p>`).join("");
    // No explicit author: ChatMessage's author field defaults to the creating user, which is what
    // we want (only the GM client posts these). v13+ removed the old `user` create-data key.
    ChatMessage.create({
      whisper: gmIds,
      speaker: {alias: "Dice Fudger"},
      content: `<div class="dice-fudger-gm-note">${content}</div>`,
      flags: {[MODULE_ID]: {gmFudgeFailureNote: true}}
    });
  } catch (err) {
    console.warn("dice-fudger | failed to post the GM whisper about a fudge:", err);
  }
}

/**
 * Post a GM whisper explaining why an armed next-roll fudge could not be (fully) applied.
 * @param {object|null} armed          The armed fudge state ({outcome, actorId}) being reported on
 * @param {Roll|null} roll             The roll the fudge attempt was made against (for labeling)
 * @param {string} reason              Why the fudge could not be applied as requested
 * @param {object} [options]
 * @param {string} [options.detail]    Optional extra line (e.g. what the roll actually landed as)
 * @param {string} [options.rollLabel] Explicit label for the roll, when it can't be derived from
 *                                     a Roll object (e.g. for a message that arrived from
 *                                     another user's client)
 */
function _whisperGmFudgeFailure(armed, roll, reason, {detail = "", rollLabel = null} = {}) {
  const outcomeLabel = OUTCOME_LABELS[armed?.outcome] ?? armed?.outcome ?? "an unknown outcome";
  const targetName = armed?.actorId ? (game.actors?.get(armed.actorId)?.name ?? "an unknown actor") : null;
  const label = rollLabel ?? (roll ? (_describeRollSource(roll) || "an unnamed roll") : "a roll");
  _postGmWhisper([
    `<strong>🎲 Dice Fudger - could not force ${outcomeLabel}${targetName ? ` for ${targetName}` : ""}</strong>`,
    `Roll: <strong>${label}</strong>`,
    `Reason: ${reason}`,
    ...(detail ? [detail] : []),
    `<em>The armed next-roll fudge has been cleared - arm it again if you still need it.</em>`
  ]);
}

/**
 * The single-roll rigging only exists on the GM's client (it is installed by DiceFudger.armNextRoll,
 * which only the GM can run) - Roll.prototype.evaluate on a PLAYER's client is never patched, so a
 * qualifying roll made by a player on their own machine posts its chat message without the fudge
 * ever being attempted, and the armed state would otherwise sit there silently forever. Detect that
 * case here as the message arrives. If the message is an unconfirmed action card or a
 * blind/whispered (still hidden) roll and the auto-apply setting is on, the fudge is applied right
 * away via the same code the "Force Outcome" buttons use; otherwise a GM whisper explains why it
 * couldn't be applied and what the GM's options are. Runs on both createChatMessage and
 * updateChatMessage, because some messages are posted empty and only get their rolls filled in by
 * a later update.
 * @param {ChatMessage} message
 */
async function _checkForeignRollAgainstArmedFudge(message) {
  const armed = _pendingSingleRollOutcome;
  if (!armed) return;
  // Foundry v13+ renamed the message author field from `user` to `author` (message.user is gone),
  // which silently made every incoming message look like our own and disabled this whole path.
  // Handle both names, and fall back to the raw source id in case the author User no longer
  // resolves (e.g. they left the server).
  const authorId = message.author?.id ?? message._source?.author ?? message.user?.id ?? null;
  if (!message || !authorId || authorId === game.user.id) return;
  if (_isGroupCheckMessage(message)) return; // group checks have their own outcome-forcing path
  const rolls = message.rolls ?? [];
  const qualifyingRolls = rolls.filter((roll) => _isFudgeableCheckRoll(roll));
  const matchingRolls = qualifyingRolls.filter((roll) => !armed.actorId ||
    ((roll.data?.actorId ?? roll.options?.data?.actorId ?? null) === armed.actorId));
  console.debug("dice-fudger | armed next-roll fudge saw a foreign chat message", {
    messageId: message.id,
    author: message.author?.name ?? authorId,
    rollCount: rolls.length,
    qualifyingCount: qualifyingRolls.length,
    matchingCount: matchingRolls.length,
    armedActorId: armed.actorId
  });
  if (!matchingRolls.length) return;

  // The roll already resolved on another client - it can never be rigged during evaluate again.
  // Consume the arming either way, then either apply the fudge now (while the message is still
  // unconfirmed or hidden) or explain why that isn't possible.
  _pendingSingleRollOutcome = null;
  _updateArmedIndicator();
  const rollerName = message.author?.name ?? message.user?.name ?? "another user";
  const rollLabel = matchingRolls.map((r) => _describeRollSource(r)).filter(Boolean)[0] ?? "a qualifying roll";
  const arrivalNote = `the roll was made by ${rollerName} on their own client. Dice Fudger's roll-time ` +
    "interception only runs on the GM's client, so it never had a chance to edit the dice before the " +
    "message was posted.";

  const blind = message.blind ?? message.data?.blind ?? false;
  const whispered = (message.whisper ?? message.data?.whisper ?? []).length > 0;
  const pendingAction = _isPendingActionMessage(message);
  const stillHidden = pendingAction || blind || whispered;

  if (stillHidden && game.settings.get(MODULE_ID, "autoApplyArmedFudge")) {
    // Deliberately silent apart from forceActionOutcome's own toast - the persistent chat-log note
    // is reserved for cases that need the GM's attention (i.e. the fudge could NOT be applied).
    await DiceFudger.forceActionOutcome(message, armed.outcome);
    return;
  }

  const guidance = pendingAction
    ? "It is an unconfirmed action card, so you can still apply the fudge yourself before confirming it: " +
      "right-click the card and choose Fudge Roll (or use the Force buttons on the card, if that setting is enabled)."
    : blind
      ? "It is a blind roll, so you can still edit it manually before revealing it (right-click the message and choose Fudge Roll)."
      : whispered
        ? "It was rolled privately (whispered), so you may still be able to edit it manually before anyone else sees it (right-click the message and choose Fudge Roll)."
        : "The result is already visible to the table, so editing it now would not be silent.";
  _whisperGmFudgeFailure(armed, null, `${arrivalNote} ${guidance}`, {rollLabel});
}

/**
 * Decide the individual outcome bracket each participant roll in a group check should be forced
 * into so that Crucible's own aggregate formula (module/dice/group-check.mjs #computeAggregate)
 * lands on the GM's requested group-level outcome.
 *
 * Crucible scores each participant (+2 critical success, +1 success, 0 failure, -1 critical
 * failure) and classifies the total against `total` (participant count) and `required`
 * (floor(total/2)+1):
 *   critical success: score >= total
 *   success:          required <= score < total
 *   failure:          0 < score < required
 *   critical failure: score <= 0
 *
 * For criticalSuccess/criticalFailure, every participant landing in that same bracket already
 * produces the matching aggregate (those brackets sit at the extremes), so uniform assignment
 * works fine. For success/failure, uniformly forcing every participant into the SAME plain
 * bracket is exactly what causes the group card to read Critical Success/Critical Failure
 * instead: if all N participants plainly succeed, score == N == total, which trips the critical
 * success branch; if all plainly fail, score == 0, which trips critical failure. Giving
 * (total - 1) participants the requested bracket and exactly one the opposite plain bracket
 * lands the score solidly inside the requested non-critical range for total >= 3 (success) or
 * total >= 2 (failure).
 *
 * Below those sizes, a plain success/failure aggregate is mathematically unreachable under
 * Crucible's own formula regardless of what any module does (there's no integer score that
 * satisfies the inequality) - e.g. a single-participant check can only ever show as critical
 * either way. In that case this falls back to uniform assignment; the card will still read as
 * critical, which is the closest achievable result.
 * @param {string} outcome  "criticalSuccess"|"success"|"failure"|"criticalFailure"
 * @param {number} count    Number of participant rolls in this group check
 * @returns {string[]}      Per-participant outcome brackets, same length as count
 */
function _computeParticipantOutcomes(outcome, count) {
  if (!Number.isFinite(count) || count < 1) return [];
  if (outcome === "success" && count >= 3) {
    return Array(count).fill(outcome).map((o, i) => i === 0 ? "failure" : o);
  }
  if (outcome === "failure" && count >= 2) {
    return Array(count).fill(outcome).map((o, i) => i === 0 ? "success" : o);
  }
  return Array(count).fill(outcome);
}

/**
 * Temporarily patches Roll.prototype.evaluate so that any Crucible check roll (identified by
 * having a `dc` on its roll data - the same signature StandardCheck/GroupCheck participant rolls
 * carry) which evaluates while this is installed gets its dice corrected to land in the requested
 * outcome bracket immediately after it resolves, before Crucible does anything else with it (in
 * particular, before it builds any chat message). Returns a function that restores the original
 * evaluate method; always call it (in a finally block) once the check this was installed for is
 * done configuring, so unrelated rolls elsewhere aren't affected.
 */
function _installRollRigging(outcome) {
  const originalEvaluate = Roll.prototype.evaluate;
  Roll.prototype.evaluate = async function(...args) {
    const result = await originalEvaluate.apply(this, args);
    try {
      if (!_isFudgeableCheckRoll(this)) return result;
      const participantOutcomes = _computeParticipantOutcomes(outcome, _pendingGroupCheckParticipantCount ?? 1);
      const participantIndex = _riggedParticipantIndex++;
      const rollOutcome = participantOutcomes[participantIndex] ?? outcome;
      const targetTotal = _chooseGroupOutcomeTotal(this, rollOutcome);
      if (targetTotal === null) {
        console.warn("dice-fudger | a participant roll in this group check has no dc/threshold data to force an outcome against - left unmodified.", {outcome, rollOutcome, participantIndex, roll: this});
        ui.notifications.warn(`Dice Fudger: couldn't force one of this group check's rolls to ${OUTCOME_LABELS[rollOutcome] ?? rollOutcome} - it has no DC/threshold data. That roll was left unmodified.`);
        return result;
      }
      const currentTotal = _evaluateRollTotal(this);
      if (currentTotal === targetTotal) return result;
      const edit = _assignDiceValuesToMatchTotal(this, targetTotal);
      if (!edit.edited && this._total !== targetTotal) this._total = targetTotal;
      if (edit.edited || typeof this.resolveDamage === "function") await _reresolveRoll(this);
      console.debug("dice-fudger | rigged roll pre-message", {outcome, rollOutcome, participantIndex, targetTotal, currentTotal});
    } catch (err) {
      console.warn("dice-fudger | failed to rig roll during evaluate:", err);
    }
    return result;
  };
  return function restore() {
    Roll.prototype.evaluate = originalEvaluate;
  };
}

Hooks.once("init", () => {
  console.log(`dice-fudger | v${game.modules.get(MODULE_ID)?.version ?? "?"} initializing`);

  game.settings.register(MODULE_ID, "hideFromActiveModules", {
    name: "Hide from Active Modules",
    hint: "If enabled, this module's entry is removed from the Manage/View Modules list for non-GM users (players can open a read-only version of that list, not just GMs). This only hides the list entry - it does not stop a player from seeing this module is installed via the browser console (game.modules) or network requests for its files.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "showActionOutcomeButtons", {
    name: "Show Force Outcome Buttons on Action Cards",
    hint: "If enabled, adds Force Critical Success / Force Success / Force Failure / Force Critical Failure buttons underneath the Confirm button on an action's pending chat card (e.g. a weapon Strike). This lets the GM fudge that action's already-rolled dice in place before confirming it, without needing the chat message context menu or the Fudge Next Roll macro. The buttons only appear on cards that haven't been confirmed yet, and only edit the roll - you still click Confirm yourself when you're ready to apply it.",
    scope: "world",
    config: true,
    type: Boolean,
    default: false
  });

  game.settings.register(MODULE_ID, "autoApplyArmedFudge", {
    name: "Auto-Apply Armed Next-Roll Fudges to Player-Made Rolls",
    hint: "The Fudge Next Roll macros can only intercept rolls evaluated on the GM's own client. Rolls made by players on their own clients are already posted by the time the GM sees them. If enabled, an armed fudge is applied automatically when such a message arrives - but only while it can still be done before the outcome matters: an unconfirmed action card (edited before you click Confirm) or a blind/whispered roll that players can't see yet. Successful applications are announced only with a brief toast notification; when a fudge cannot be applied (this setting is off, or the roll was already public), a private GM-whispered chat note explains why and what your options are.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });
});

/*
 * "Hide from Active Modules" - previously implemented as a CSS class toggled on <body>, matched
 * against the Manage Modules dialog's internal `.package.active[data-module-id="..."]` markup.
 * That was wrong on two counts:
 *  1. It assumed only the GM could open that dialog. Foundry's own settings sidebar template
 *     (templates/sidebar/apps/module-management.hbs via templates/sidebar/tabs/settings.hbs)
 *     shows the same "Manage Modules" button to every user - non-GMs just get it relabeled to
 *     "View Modules" and a read-only, active-modules-only list. Any player can open it.
 *  2. Tying the hide to specific internal class names is brittle across Foundry versions.
 *
 * Instead, hook the dialog's own render lifecycle (ApplicationV2 fires `render<ClassName>`, so
 * this ModuleManagement app fires "renderModuleManagement" - confirmed in
 * client/applications/api/application.mjs's `#callHooks`) and remove our own list entry by its
 * stable `data-module-id` attribute directly from the rendered DOM. This doesn't depend on the
 * dialog's internal class structure and keeps working even after the player uses the search box
 * or the active/inactive filter (both of those just toggle `.hidden` on the existing <li>
 * elements rather than re-rendering, so once the node is removed it stays gone).
 */
Hooks.on("renderModuleManagement", (_app, element) => {
  if (game.user?.isGM) return;
  if (!game.settings.get(MODULE_ID, "hideFromActiveModules")) return;
  const el = element instanceof HTMLElement ? element : element?.[0];
  const entry = el?.querySelector(`[data-module-id="${MODULE_ID}"]`);
  entry?.remove();
});

Hooks.once("ready", async () => {
  if (!game.user?.isGM) return;
  const macrosToEnsure = [
    {
      flag: "isFudgeNextRollMacro",
      name: "Fudge Next Roll (Anyone)",
      command: "DiceFudger.promptArmNextRoll();"
    },
    {
      flag: "isFudgeNextPlayerRollMacro",
      name: "Fudge Next Roll (Choose Player)",
      command: "DiceFudger.promptArmNextRollForPlayer();"
    }
  ];
  for (const {flag, name, command} of macrosToEnsure) {
    const flagPath = `flags.${MODULE_ID}.${flag}`;
    const existing = game.macros.find(m => foundry.utils.getProperty(m, flagPath));
    if (existing) continue;
    try {
      await Macro.create({
        name,
        type: "script",
        img: "icons/svg/d20-black.svg",
        command,
        // Explicit, rather than relying on the schema default: only the GM (and other GM
        // accounts, which always bypass ownership checks) can see or run this in the Macro Directory.
        ownership: {default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE},
        flags: {[MODULE_ID]: {[flag]: true}}
      });
      console.log(`dice-fudger | created "${name}" macro in the Macro Directory - drag it onto your hotbar.`);
    } catch (err) {
      console.warn(`dice-fudger | failed to auto-create the "${name}" macro:`, err);
    }
  }
});


Hooks.once("ready", () => {
  const GroupCheck = _getGroupCheckClass();
  if (!GroupCheck || typeof GroupCheck.configure !== "function" || GroupCheck.configure._diceFudgerPatched) return;

  const originalConfigure = GroupCheck.configure;
  GroupCheck.configure = async function(options = {}) {
    const outcome = await DiceFudger.promptPreRollOutcome();
    if (!outcome) return originalConfigure.call(this, options);

    _pendingGroupCheckOutcome = outcome;
    console.debug("dice-fudger | pre-roll outcome armed:", outcome);

    // Rig dice as each participant's Roll evaluates, BEFORE Crucible ever builds the chat
    // message. This way Crucible renders the group-check card itself, from its own real
    // (already-correct) roll data, the normal way -- we never touch its private rendering
    // internals, so nothing needs correcting after the fact and players never see a "wrong"
    // result flash before a later fix.
    const restoreRigging = _installRollRigging(outcome);
    try {
      return await originalConfigure.call(this, options);
    } finally {
      restoreRigging();
      // createChatMessage/updateChatMessage below remain as a fallback in case some roll in
      // this check didn't go through Roll.prototype.evaluate (e.g. a pre-evaluated Roll was
      // reused) and so the rigging above missed it.
    }
  };
  GroupCheck.configure._diceFudgerPatched = true;

  // Capture the participant count as soon as it's known (requestSubmit receives
  // requestedActors before any query is dispatched or any roll is evaluated), so the pre-roll
  // rigging installed above can distribute outcomes across participants instead of forcing every
  // single one into the same bracket. See _computeParticipantOutcomes for why that distinction
  // matters for plain success/failure.
  if (typeof GroupCheck.prototype?.requestSubmit === "function" && !GroupCheck.prototype.requestSubmit._diceFudgerPatched) {
    const originalRequestSubmit = GroupCheck.prototype.requestSubmit;
    GroupCheck.prototype.requestSubmit = async function(options = {}) {
      if (_pendingGroupCheckOutcome) {
        const requested = options?.requestedActors;
        const count = requested?.size ?? requested?.length ?? (requested ? Array.from(requested).length : null);
        _pendingGroupCheckParticipantCount = Number.isFinite(count) ? count : null;
        _riggedParticipantIndex = 0;
        console.debug("dice-fudger | group check participant count captured", {count: _pendingGroupCheckParticipantCount});
      }
      return originalRequestSubmit.call(this, options);
    };
    GroupCheck.prototype.requestSubmit._diceFudgerPatched = true;
  }
});

Hooks.on("createChatMessage", async (message) => {
  if (!game.user.isGM) return;
  // A qualifying roll that just arrived from a DIFFERENT user means the GM-side interception never
  // ran for it (see _checkForeignRollAgainstArmedFudge) - apply it if still possible, or report.
  await _checkForeignRollAgainstArmedFudge(message);
  const outcome = _pendingGroupCheckOutcome;
  if (!outcome) return;
  console.debug("dice-fudger | createChatMessage saw pending outcome", {
    outcome, messageId: message.id, isGroupCheck: _isGroupCheckMessage(message), rollCount: message.rolls?.length
  });
  if (!_isGroupCheckMessage(message)) return;
  _pendingGroupCheckOutcome = null;

  // Some Crucible versions post the group-check message already fully resolved (rolls present
  // on creation), others post an empty placeholder and fill in `rolls` on a later update. Handle
  // both: if the rolls are already here, force the outcome now instead of queuing it to wait for
  // an update event that may never come.
  if (message.rolls?.length) {
    const success = await DiceFudger.forceGroupOutcome(message, outcome, {silent: true});
    if (success) return;
  }
  _pendingGroupCheckMessages.set(message.id, outcome);
});

Hooks.on("updateChatMessage", async (message) => {
  if (!game.user.isGM) return;
  // Messages posted empty and filled in by a later update can also be the first time the GM client
  // sees a foreign qualifying roll, so re-check the armed fudge here too.
  await _checkForeignRollAgainstArmedFudge(message);
  const outcome = _pendingGroupCheckMessages.get(message.id);
  if (!outcome) return;
  console.debug("dice-fudger | updateChatMessage saw queued outcome", {
    outcome, messageId: message.id, isGroupCheck: _isGroupCheckMessage(message), rollCount: message.rolls?.length
  });
  if (!_isGroupCheckMessage(message)) return;
  if (!message.rolls?.length) return;
  const success = await DiceFudger.forceGroupOutcome(message, outcome, {silent: true});
  if (success) _pendingGroupCheckMessages.delete(message.id);
});

Hooks.on("getChatMessageContextOptions", (message, options) => {
  if (!game.user.isGM) return;

  options.push({
    label: "Fudge Roll",
    icon: '<i class="fas fa-dice-d20"></i>',
    visible: (li) => {
      const msg = _resolveMessage(li);
      return !!msg && _getEditableDice(msg).length > 0;
    },
    onClick: (_event, li) => {
      const msg = _resolveMessage(li);
      if (msg) DiceFudger.open(msg);
    }
  });

  options.push({
    label: "Force Group Outcome",
    icon: '<i class="fas fa-dice-d20"></i>',
    visible: (li) => {
      const msg = _resolveMessage(li);
      return !!msg && _isGroupCheckMessage(msg);
    },
    onClick: async (_event, li) => {
      const msg = _resolveMessage(li);
      if (!msg) return;
      const outcome = await new Promise((resolve) => {
        new Dialog({
          title: "Force Group Outcome",
          content: "<p>Select the desired group outcome.</p>",
          buttons: {
            criticalSuccess: {
              label: "Critical Success",
              callback: () => resolve("criticalSuccess")
            },
            success: {
              label: "Success",
              callback: () => resolve("success")
            },
            failure: {
              label: "Failure",
              callback: () => resolve("failure")
            },
            criticalFailure: {
              label: "Critical Failure",
              callback: () => resolve("criticalFailure")
            }
          },
          default: "success",
          close: () => resolve(null)
        }).render(true);
      });
      if (outcome) await DiceFudger.forceGroupOutcome(msg, outcome);
    }
  });
});

/**
 * Foundry v13+ replaced the legacy jQuery `renderChatMessage` hook with `renderChatMessageHTML`,
 * which fires with a raw HTMLElement instead of a jQuery collection (and, as of this module's
 * targeted v14, `renderChatMessage` no longer fires at all). Handle both hooks and both calling
 * conventions so the button-injection code below - which uses jQuery's .find()/.after()/etc
 * throughout - always gets a jQuery object to work with.
 * @param {HTMLElement|JQuery} html
 * @returns {JQuery}
 */
function _toJQuery(html) {
  return html?.jquery ? html : $(html);
}

function _onRenderChatMessage(app, html) {
  if (!game.user.isGM) return;
  const message = app.message ?? app; // v13+ passes the ChatMessage directly, not an app wrapper
  html = _toJQuery(html);
  if (_isGroupCheckMessage(message)) {
    _buildGroupOutcomeButtons(html, message);
    return;
  }
  if (game.settings.get(MODULE_ID, "showActionOutcomeButtons") && _isPendingActionMessage(message)) {
    _buildActionOutcomeButtons(html, message);
  }
}

// Only hook the modern "renderChatMessageHTML" hook. Foundry calls the deprecated
// "renderChatMessage" hook internally for back-compat ONLY when something has a listener
// registered on it - registering here was itself what triggered the "renderChatMessage hook is
// deprecated" warning spam on every chat render. Worse, both hooks then fired for the same
// render, so _onRenderChatMessage ran twice per message against two different html references,
// which could race with the ".dice-fudger-*-buttons already built" dedupe check and leave the
// button bar appended to the wrong (or a since-discarded) copy of the card - the likeliest cause
// of the buttons/context-menu intermittently not working. v13/v14 both fire
// renderChatMessageHTML, so the legacy hook was never actually needed here.
Hooks.on("renderChatMessageHTML", _onRenderChatMessage);

/**
 * Support both the raw-element (v13/v14) and jQuery (legacy) context-menu calling conventions.
 * @param {HTMLElement|object} li
 * @returns {ChatMessage|null}
 */
function _resolveMessage(li) {
  const id = li?.dataset?.messageId ?? li?.data?.("messageId") ?? li?.[0]?.dataset?.messageId;
  return id ? game.messages.get(id) : null;
}

/**
 * Collect every editable die across every Roll on a message.
 * @param {ChatMessage} message
 * @returns {{roll: Roll, rollIndex: number, term: object, termIndex: number, dieIndex: number,
 *            faces: number, value: number}[]}
 */
function _getEditableDice(message) {
  const entries = [];
  const rolls = message.rolls ?? [];
  rolls.forEach((roll, rollIndex) => {
    if (!roll?._evaluated) return;
    roll.terms.forEach((term, termIndex) => {
      if (!(term instanceof foundry.dice.terms.DiceTerm)) return;
      term.results.forEach((r, dieIndex) => {
        if (r.discarded) return; // don't offer to edit discarded (e.g. dropped-lowest) dice
        entries.push({
          roll, rollIndex, term, termIndex, dieIndex,
          faces: term.faces, value: r.result
        });
      });
    });
  });
  return entries;
}

function _getEditableDiceFromRoll(roll) {
  const entries = [];
  if (!roll?._evaluated) return entries;
  roll.terms.forEach((term, termIndex) => {
    if (!(term instanceof foundry.dice.terms.DiceTerm)) return;
    term.results.forEach((r, dieIndex) => {
      if (r.discarded) return;
      entries.push({roll, term, termIndex, dieIndex, faces: term.faces, value: r.result});
    });
  });
  return entries;
}

/**
 * Build a human-readable "who this roll belongs to" label (e.g. "Aria → Goblin Archer") so the
 * Fudge Roll dialog can identify each roll by actor/target instead of just its position in
 * `message.rolls` - that index is an internal array order and has no guaranteed relationship to
 * the order targets are listed on the rendered chat card, which is what made multi-target attacks
 * (roll 1 of 3 targets = which target?) impossible to tell apart before.
 * @param {Roll} roll
 * @returns {string} "" if neither an actor nor a target could be resolved
 */
function _describeRollSource(roll) {
  const parts = [];
  // Rolls reconstructed from another user's chat message keep their custom data under
  // `options.data` rather than `data`, so check both when resolving actor/target labels.
  const actorId = roll.data?.actorId ?? roll.options?.data?.actorId ?? roll.actor?.id ?? null;
  const actor = actorId ? (game.actors?.get(actorId) ?? null) : (roll.actor ?? null);
  if (actor?.name) parts.push(actor.name);

  const targetUuid = roll.data?.target ?? roll.options?.data?.target ?? null;
  if (targetUuid) {
    try {
      const target = fromUuidSync(targetUuid);
      const targetName = target?.name ?? target?.actor?.name ?? null;
      if (targetName) parts.push(`→ ${targetName}`);
    } catch (err) {
      console.warn("dice-fudger | failed to resolve roll target for labeling:", err, {targetUuid});
    }
  }
  return parts.join(" ");
}

/**
 * Whether a Roll looks like a Crucible check that an outcome fudge can act on. StandardCheck-style
 * checks and AttackRolls carry a `dc` on their roll data (AttackRoll.defaultData inherits it and
 * its overflow getter reads it); AttackRoll additionally exposes resolveDamage(), which also covers
 * rolls reconstructed from another user's chat message - Roll.fromData rebuilds the registered
 * system subclass (Crucible pushes its classes into CONFIG.Dice.rolls), so the method survives the
 * round-trip even if a future version ever dropped dc from the serialized data.
 * @param {Roll} roll
 * @returns {boolean}
 */
function _isFudgeableCheckRoll(roll) {
  if (!roll?._evaluated) return false;
  const data = roll.data ?? roll.options?.data ?? {};
  return ("dc" in data) || ("dc" in (data.data ?? {})) || typeof roll.resolveDamage === "function";
}

function _evaluateRollTotal(roll) {
  if (typeof roll._evaluateTotal === "function") return roll._evaluateTotal();
  if (typeof roll.total === "number") return roll.total;
  return _recomputeTotalFallback(roll);
}

function _clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

/**
 * @param {number[]} faces      Face count of each die in the pool
 * @param {number} requestedSum The sum the caller would like the dice to add up to
 * @returns {{values: number[], requestedSum: number, achievedSum: number}}
 *   `achievedSum` differs from `requestedSum` when the request was outside the pool's physical
 *   [count, sum(faces)] range and had to be clamped - callers should compare the two and warn the
 *   GM rather than silently presenting the clamped result as if it were what was asked for.
 */
function _distributeSumAcrossDice(faces, requestedSum) {
  const count = faces.length;
  const minSum = count;
  const maxSum = faces.reduce((sum, f) => sum + f, 0);
  const targetSum = _clamp(requestedSum, minSum, maxSum);

  const values = Array(count).fill(1);
  let remaining = targetSum - minSum;
  const order = Array.from({length: count}, (_, i) => i).sort(() => Math.random() - 0.5);
  for (const i of order) {
    const cap = faces[i] - 1;
    if (!cap) continue;
    const add = Math.floor(Math.random() * Math.min(cap, remaining + 1));
    values[i] += add;
    remaining -= add;
    if (!remaining) break;
  }
  for (let i = count - 1; i >= 0 && remaining > 0; i--) {
    const cap = faces[i] - values[i];
    const add = Math.min(cap, remaining);
    values[i] += add;
    remaining -= add;
  }
  return {values, requestedSum, achievedSum: targetSum};
}

const FORCE_OUTCOME_BUTTONS = [
  {action: "criticalSuccess", label: "Critical Success"},
  {action: "success", label: "Success"},
  {action: "failure", label: "Failure"},
  {action: "criticalFailure", label: "Critical Failure"}
];

/**
 * Build a "force outcome" button bar (4 buttons: crit success / success / failure / crit
 * failure). Shared by the group-check bar and the pending-action-card bar, which differ only in
 * their CSS class, label prefix, click handler, and where they get inserted into the card - all
 * of that is left to the caller.
 * @param {string} cssClass    Wrapper class, also used as the "already built" dedupe check by callers
 * @param {string} labelPrefix Prepended to each button's label, e.g. "Force Group " or "Force "
 * @param {(action: string) => Promise<void>} onClick
 * @returns {JQuery}
 */
function _buildOutcomeButtonBar(cssClass, labelPrefix, onClick) {
  const buttonBar = $(`<div class="${cssClass} flexrow"></div>`);
  for (const button of FORCE_OUTCOME_BUTTONS) {
    buttonBar.append(
      $(`<button type="button" class="button dice-fudger-outcome-${button.action}" data-outcome="${button.action}">${labelPrefix}${button.label}</button>`)
        .data("diceFudgerAction", button.action)
    );
  }
  buttonBar.on("click", "button", async (event) => {
    event.preventDefault();
    const action = $(event.currentTarget).data("diceFudgerAction");
    if (!action) return;
    await onClick(action);
  });
  return buttonBar;
}

function _buildGroupOutcomeButtons(html, message) {
  if (html.find(".dice-fudger-group-outcome-buttons").length) return;
  const buttonBar = _buildOutcomeButtonBar(
    "dice-fudger-group-outcome-buttons",
    "Force Group ",
    (action) => DiceFudger.forceGroupOutcome(message, action)
  );

  const content = html.find(".message-content").first();
  if (!content.length) return;
  content.addClass("dice-fudger-has-buttons");
  content.css({overflowY: "auto", maxHeight: "calc(100vh - 12rem)"});
  buttonBar.css({position: "sticky", bottom: 0, zIndex: 2, background: "rgba(0,0,0,0.95)", padding: "0.35rem 0"});
  content.append(buttonBar);
}

/**
 * Whether this message is a not-yet-confirmed Crucible action-use card (e.g. a weapon Strike),
 * as opposed to a confirmed one or some other message type entirely. Matches the same
 * `flags.crucible.confirmed` gate Crucible itself uses to decide whether to show its own Confirm
 * button (see CrucibleAction#confirm, which flips this flag once the GM confirms).
 * @param {ChatMessage} message
 * @returns {boolean}
 */
function _isPendingActionMessage(message) {
  const flags = message?.flags?.crucible ?? message?.data?.flags?.crucible;
  if (!flags || !("action" in flags)) return false;
  if (flags.confirmed !== false) return false; // already confirmed, or not an action that tracks confirmation
  return !!message.rolls?.length;
}

/**
 * Locate the card's own "Confirm" button in the rendered DOM. Crucible doesn't expose a stable
 * public API for this. Crucible renders it as `<button class="confirm ...">`, so that's tried
 * first, then the conventional `data-action="confirm"` attribute (matching how Crucible wires
 * some of its other card buttons, e.g. "reverse", "expand"), and finally falls back to matching
 * the button by its visible text in case a future Crucible version renames both.
 * @param {JQuery} html
 * @returns {JQuery} A jQuery collection with 0 or 1 elements
 */
function _findConfirmButton(html) {
  let btn = html.find("button.confirm");
  if (btn.length) return btn.first();
  btn = html.find('[data-action="confirm"]');
  if (btn.length) return btn.first();
  btn = html.find("button, a.button").filter((_i, el) => $(el).text().trim().toLowerCase() === "confirm");
  return btn.first();
}

function _buildActionOutcomeButtons(html, message) {
  if (html.find(".dice-fudger-action-outcome-buttons").length) return;
  const confirmButton = _findConfirmButton(html);
  if (!confirmButton.length) return;

  const buttonBar = _buildOutcomeButtonBar(
    "dice-fudger-action-outcome-buttons",
    "Force ",
    (action) => DiceFudger.forceActionOutcome(message, action)
  );

  // Insert as a new row directly under Confirm. If Confirm sits in its own footer/wrapper *inside
  // the card*, insert after that wrapper instead of after the bare button so the bar doesn't end
  // up squeezed onto the same flex row as Confirm. But if Confirm is a direct child of the message
  // root (the <li class="chat-message">... element `html` itself wraps), climbing to the parent
  // would mean inserting the bar as a sibling of the whole message in the chat log - a stray node
  // Foundry won't render. In that case, insert directly after the bare button instead.
  const messageRoot = html[0];
  const wrapper = confirmButton.parent();
  const wrapperIsMessageRoot = wrapper.length && messageRoot && wrapper[0] === messageRoot;
  const target = (wrapper.length && !wrapperIsMessageRoot && !wrapper.is("body,html")) ? wrapper : confirmButton;
  buttonBar.css({flex: "1 1 100%", width: "100%"});
  target.after(buttonBar);
}

function _parseCheckMetadata(roll) {
  const data = roll.data ?? {};
  const nestedData = data.data ?? {};
  const dc = Number.isFinite(Number(data.dc))
    ? Number(data.dc)
    : Number.isFinite(Number(nestedData.dc))
      ? Number(nestedData.dc)
      : Number.isFinite(Number(roll.options?.dc))
        ? Number(roll.options.dc)
        : 15;
  const criticalSuccessThreshold = Number.isFinite(Number(data.criticalSuccessThreshold))
    ? Number(data.criticalSuccessThreshold)
    : Number.isFinite(Number(nestedData.criticalSuccessThreshold))
      ? Number(nestedData.criticalSuccessThreshold)
      : Number.isFinite(Number(data.critThreshold))
        ? Number(data.critThreshold)
        : Number.isFinite(Number(nestedData.critThreshold))
          ? Number(nestedData.critThreshold)
          : 6;
  const criticalFailureThreshold = Number.isFinite(Number(data.criticalFailureThreshold))
    ? Number(data.criticalFailureThreshold)
    : Number.isFinite(Number(nestedData.criticalFailureThreshold))
      ? Number(nestedData.criticalFailureThreshold)
      : Number.isFinite(Number(data.critFailureThreshold))
        ? Number(data.critFailureThreshold)
        : Number.isFinite(Number(nestedData.critFailureThreshold))
          ? Number(nestedData.critFailureThreshold)
          : 6; // Crucible's own default (standard-check.mjs `this.data.criticalFailureThreshold ?? 6`)
  return {dc, criticalSuccessThreshold, criticalFailureThreshold};
}

/**
 * The total range a given outcome bracket occupies for a roll, using the same bracket bounds
 * Crucible's StandardCheck getters use (success = dc+1 upward, critical success = dc plus the
 * critical success threshold, failure = dc downward through the critical failure threshold).
 * Split out of _chooseGroupOutcomeTotal so the next-roll fudge's failure reporting can show the
 * GM the range the requested outcome actually needed.
 * @param {Roll} roll
 * @param {string} outcome  "criticalSuccess"|"success"|"failure"|"criticalFailure"
 * @returns {{min: number, max: number}|null} null if the roll's dc/threshold data is unusable
 */
function _outcomeBounds(roll, outcome) {
  const {dc, criticalSuccessThreshold, criticalFailureThreshold} = _parseCheckMetadata(roll);
  if (!Number.isFinite(dc) || !Number.isFinite(criticalSuccessThreshold) || !Number.isFinite(criticalFailureThreshold)) return null;
  const successMin = dc + 1;
  const criticalSuccessMin = dc + criticalSuccessThreshold;
  const successMax = Math.max(successMin, criticalSuccessMin - 1);
  const criticalSuccessMax = Math.max(criticalSuccessMin, criticalSuccessMin + 5);
  const failureMin = Math.max(-(2 ** 31), dc - (criticalFailureThreshold - 1));
  const failureMax = dc;
  const criticalFailureMax = Math.min(failureMax - 1, dc - criticalFailureThreshold - 1);
  const criticalFailureMin = Math.max(-(2 ** 31), criticalFailureMax - 5);

  switch (outcome) {
    case "criticalSuccess":
      return {min: criticalSuccessMin, max: criticalSuccessMax};
    case "success":
      return {min: successMin, max: successMax};
    case "failure":
      return {min: failureMin, max: failureMax};
    case "criticalFailure":
      return {min: criticalFailureMin, max: criticalFailureMax};
    default:
      return null;
  }
}

function _chooseGroupOutcomeTotal(roll, outcome) {
  const bounds = _outcomeBounds(roll, outcome);
  if (!bounds) return null;
  return _randomInt(bounds.min, bounds.max);
}

/**
 * The inverse of _outcomeBounds: which outcome bracket a finished total falls into for this roll.
 * Used to tell the GM what a clamped (physically unreachable) fudge actually landed as.
 * @param {Roll} roll
 * @param {number} total
 * @returns {string|null} an OUTCOME_LABELS key, or null if the roll's dc data is unusable
 */
function _outcomeBracketForTotal(roll, total) {
  const {dc, criticalSuccessThreshold, criticalFailureThreshold} = _parseCheckMetadata(roll);
  if (!Number.isFinite(dc) || !Number.isFinite(criticalSuccessThreshold) || !Number.isFinite(criticalFailureThreshold)) return null;
  if (total >= dc + criticalSuccessThreshold) return "criticalSuccess";
  if (total > dc) return "success";
  if (total >= dc - (criticalFailureThreshold - 1)) return "failure";
  return "criticalFailure";
}

function _randomInt(min, max) {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return null;
  if (max < min) max = min;
  if (min === max) return min;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function _getGroupCheckClass() {
  return globalThis.GroupCheck
    ?? window?.GroupCheck
    ?? globalThis.crucible?.api?.dice?.GroupCheck
    ?? window?.crucible?.api?.dice?.GroupCheck
    ?? null;
}

async function _renderGroupCheckContent(message) {
  if (!message?.rolls?.length) return null;
  const GroupCheck = _getGroupCheckClass();
  if (!GroupCheck || typeof GroupCheck.renderGroupCheckCard !== "function") return null;
  const rawFlags = {
    ...(message.data?.flags ?? {}),
    ...(message.flags ?? {})
  };
  // Crucible's renderGroupCheckCard expects the *actual* GroupCheckFlags object - the one with
  // .actors/.aggregate/etc - which as of Crucible 0.10.2 is nested one level deeper than the
  // raw `flags.crucible` wrapper, under GroupCheck.FLAG_KEY (currently "groupCheck"):
  //   message.flags.crucible[GroupCheck.FLAG_KEY]  ->  {actors, aggregate, skills, ...}
  // Neither `flags.crucible` alone nor the raw `flags` wrapper has an `.actors` property, so
  // passing either straight to renderGroupCheckCard throws inside Crucible's own code (caught
  // below) and content silently fails to regenerate - which is what made fudged/forced group
  // check outcomes edit the roll data correctly but never visibly update the chat card. Read
  // FLAG_KEY off the class itself (rather than hardcoding "groupCheck") so this keeps working if
  // a future Crucible version renames it, and keep the older/flatter shapes as fallbacks for
  // resilience against other Crucible versions.
  const crucibleFlags = rawFlags.crucible ?? {};
  const flagKey = GroupCheck.FLAG_KEY ?? "groupCheck";
  const flagCandidates = [crucibleFlags[flagKey], crucibleFlags, rawFlags].filter(Boolean);
  const rollObjects = message.rolls ?? [];
  const rollJson = rollObjects.map((roll) => typeof roll.toJSON === "function" ? roll.toJSON() : roll);
  for (const flags of flagCandidates) {
  for (const rolls of [rollObjects, rollJson]) {
    try {
      const result = GroupCheck.renderGroupCheckCard(flags, rolls);
      const content = result instanceof Promise ? await result : result;
      if (typeof content === "string") return content;
      if (content?.outerHTML) return content.outerHTML;
      if (content?.html && typeof content.html === "function") {
        const html = content.html();
        if (typeof html === "string") return html;
      }
      if (content instanceof DocumentFragment) {
        const wrapper = document.createElement("div");
        wrapper.appendChild(content.cloneNode(true));
        return wrapper.innerHTML;
      }
      if (Array.isArray(content) && content.length) {
        const wrapper = document.createElement("div");
        content.forEach((item) => {
          if (item?.outerHTML) wrapper.appendChild(item.cloneNode(true));
          else if (item?.html && typeof item.html === "function") {
            const temp = document.createElement("div");
            temp.innerHTML = item.html();
            wrapper.append(...Array.from(temp.children));
          }
        });
        return wrapper.innerHTML || null;
      }
      console.warn("dice-fudger | renderGroupCheckCard returned unknown content type:", content);
    } catch (err) {
      console.warn("dice-fudger | renderGroupCheckCard attempt failed:", err);
    }
  }
  }
  return null;
}

function _isGroupCheckMessage(message) {
  if (!message || !Array.isArray(message.rolls) || message.rolls.length <= 1) return false;
  const content = String(message.data?.content ?? message.content ?? "");
  if (/group[- ]check|groupcheck|group-check/i.test(content)) return true;
  const flags = message.data?.flags ?? message.flags ?? {};
  if (flags && typeof flags === "object") {
    const flagsText = JSON.stringify(flags);
    if (/group[- ]check|groupcheck|group-check/i.test(flagsText)) return true;
  }
  return false;
}

function _assignDiceValuesToMatchTotal(roll, targetTotal) {
  const entries = _getEditableDiceFromRoll(roll);
  if (!entries.length) return {edited: false, clamped: false};
  const currentTotal = _evaluateRollTotal(roll);
  const currentDiceTotal = entries.reduce((sum, e) => sum + Number(e.value), 0);
  const fixedTotal = currentTotal - currentDiceTotal;
  const targetDiceTotal = targetTotal - fixedTotal;
  const faces = entries.map((e) => e.faces);
  const {values, requestedSum, achievedSum} = _distributeSumAcrossDice(faces, targetDiceTotal);
  const clamped = achievedSum !== requestedSum;
  if (clamped) {
    const achievedTotal = achievedSum + fixedTotal;
    console.warn("dice-fudger | requested total is outside what these dice can physically produce - clamped to " +
      "the nearest achievable value.", {requestedTotal: targetTotal, achievedTotal, faces});
    ui.notifications.warn(
      `Dice Fudger: the requested total (${targetTotal}) isn't possible with these dice - used the closest ` +
      `achievable value (${achievedTotal}) instead.`
    );
  }
  values.forEach((value, index) => {
    const entry = entries[index];
    entry.term.results[entry.dieIndex].result = value;
  });
  if (typeof roll._evaluateTotal === "function") {
    roll._total = roll._evaluateTotal();
  } else {
    _recomputeTotalFallback(roll);
  }
  if (roll.data && typeof roll.data === "object") {
    roll.data.total = roll._total;
    if ("result" in roll.data) roll.data.result = roll._total;
  }
  return {edited: true, clamped, requestedTotal: targetTotal, achievedTotal: achievedSum + fixedTotal};
}

/**
 * Fallback total recompute for the rare case where a Foundry build doesn't expose the internal
 * `_evaluateTotal()` method. Walks terms left-to-right applying +/- OperatorTerms only.
 * @param {Roll} roll
 * @returns {number} the recomputed total
 */
function _recomputeTotalFallback(roll) {
  let total = 0;
  let sign = 1;
  for (const term of roll.terms) {
    if (term instanceof foundry.dice.terms.OperatorTerm) {
      sign = term.operator === "-" ? -1 : 1;
      continue;
    }
    const t = Number(term.total);
    total += sign * (Number.isFinite(t) ? t : 0);
    sign = 1;
  }
  roll._total = total;
  return total;
}

/**
 * Look up Crucible's resource-type config (specifically whether a resource is a "reserve" pool,
 * which flips the sign of damage against it - see CrucibleAction##resolveEventStream,
 * module/models/action.mjs line ~2018: `cfg.type === "reserve" ? -1 : 1`) from whichever global
 * this Crucible build happens to expose it on. Best-effort: if it can't be found, this assumes
 * "not reserve" (the common case - health/morale) and warns, rather than throwing.
 * @param {string} resource
 * @returns {boolean}
 */
function _isReserveResourceType(resource) {
  const cfg = globalThis.SYSTEM?.RESOURCES?.[resource]
    ?? CONFIG.SYSTEM?.RESOURCES?.[resource]
    ?? game.system?.SYSTEM?.RESOURCES?.[resource]
    ?? game.system?.config?.RESOURCES?.[resource]
    ?? null;
  if (!cfg) {
    console.warn(`dice-fudger | couldn't find Crucible's resource config for "${resource}" - assuming it isn't a ` +
      "reserve pool. If it actually is, the confirmed damage sign for this fudge may be inverted.");
    return false;
  }
  return cfg.type === "reserve";
}

/**
 * Mirror the roll-damage branch of CrucibleAction##resolveEventStream (module/models/action.mjs line ~2011) for a
 * single roll, using only the fields available directly on the (now-fudged) roll itself:
 *
 *   const resource = damage.resource ?? "health";
 *   intended[resource] = (damage.total ?? 0) * (restoration ? 1 : -1) * (cfg.type === "reserve" ? -1 : 1);
 *
 * This is what Crucible itself uses to compute the resource delta it freezes into
 * `message.flags.crucible.events[].resources` at the moment an action is first used - BEFORE any GM fudge can
 * happen. Confirming an action later never re-runs that computation; it reads the frozen `resources` array
 * verbatim (CrucibleAction##applyEvents, line ~2663), so fixing `roll.data.damage.total` alone (which is all
 * `resolveDamage()` does) is not enough - the frozen flag data has to be corrected too, or Confirm applies the
 * pre-fudge amount. That's the root cause of damage not updating when a roll is fudged after its message exists.
 * @param {Roll} roll   A roll whose `resolveDamage()` has already been re-run (so `roll.data.damage` is current)
 * @returns {{resource: string, delta: number, damageType: string|undefined, restoration: boolean}|null}
 *   null if this roll doesn't carry (non-harmless) damage data at all
 */
function _recomputeCrucibleEventResourceForRoll(roll) {
  const damage = roll?.data?.damage;
  if (!damage || damage.harmless) return null;
  const resource = damage.resource ?? "health";
  const restoration = !!damage.restoration;
  const isReserve = _isReserveResourceType(resource);
  const total = Number(damage.total) || 0;
  const delta = total * (restoration ? 1 : -1) * (isReserve ? -1 : 1);
  return {resource, delta, damageType: damage.type, restoration};
}

/**
 * Given a message's current `flags.crucible.events` array, return a corrected copy that reflects a fudged roll's
 * new damage total, or the same array unchanged if there's nothing to correct.
 *
 * Deliberately conservative: Crucible's real #resolveEventStream computes the frozen `resources` by simulating the
 * delta against an actor clone (`actor.alterResources(..., {commit: false, constraints})`), which can apply
 * resistances, clamp against current resource values, and overflow into a second linked pool. This module has no
 * access to that private simulation (or the `resourceConstraints` it used), so it only handles the common case -
 * an event whose frozen `resources` is exactly the one entry the roll's own damage produced, with no overflow. If
 * an event's frozen data looks more complex than that (more than one resource entry), this leaves it untouched and
 * warns, rather than guessing and silently producing a wrong number.
 * @param {object[]} events    The message's current (possibly already-corrected-once) events array
 * @param {ChatMessage} message
 * @param {Roll} roll          The roll that was just fudged and re-resolved
 * @param {{changed: boolean}} tracker  Set .changed = true if a correction was made
 * @returns {object[]}
 */
function _applyFudgedEventResources(events, message, roll, tracker) {
  if (!Array.isArray(events) || !events.length) return events;
  const rollIndex = message.rolls?.indexOf(roll);
  if (rollIndex == null || rollIndex < 0) return events;
  const recomputed = _recomputeCrucibleEventResourceForRoll(roll);
  if (!recomputed) return events; // no (non-harmless) damage on this roll - nothing to correct here
  return events.map((event) => {
    if (event?.rollIndex !== rollIndex) return event;
    const resources = Array.isArray(event.resources) ? event.resources : [];
    if (resources.length > 1) {
      console.warn("dice-fudger | this roll's confirmed damage event has more than one recorded resource change " +
        "(likely pool overflow or a linked resource) from Crucible's own resolution - leaving " +
        "message.flags.crucible.events untouched for it. Confirmed damage/healing for this event may still " +
        "reflect the PRE-fudge amount.", {rollIndex, resources});
      ui.notifications.warn("Dice Fudger: this roll's damage involves more than one resource (e.g. pool " +
        "overflow) - the fudge to the roll total was applied, but the confirmed damage amount could not be " +
        "safely corrected and may still show the original value.");
      return event;
    }
    tracker.changed = true;
    return {...event, resources: [recomputed]};
  });
}

/**
 * Re-resolve a Roll after its underlying dice results have been edited, so every cached field
 * that depends on the dice (not just `roll.total`) is brought back in sync.
 *
 * - If the roll is (or behaves like) a Crucible AttackRoll - i.e. it exposes `resolveDamage()` -
 *   its hit/miss result and damage total were cached at initial resolution and won't update from
 *   a bare total fix. Re-run `resolveDamage(actor, target)` with no config so it reuses the
 *   damage configuration already stored on the roll, mirroring what Crucible's own "Loaded Dice"
 *   reroll talent does internally.
 * - Otherwise, just fix the cached total, preferring Foundry's own `_evaluateTotal()` (handles
 *   any formula, not just +/-) and falling back to a manual walk only if that method is absent.
 * @param {Roll} roll
 * @returns {Promise<void>}
 */
async function _reresolveRoll(roll) {
  // The dice on `roll` may have just been edited directly (term.results[i].result mutated) without
  // roll._total being refreshed yet - e.g. the manual "Fudge Roll" dialog does exactly this. Since
  // resolveDamage() (below) determines Hit/Miss/Dodge/Resisted/Glance from the roll's current total,
  // that total MUST be recomputed first, or resolveDamage silently re-derives the same pre-fudge
  // outcome from the stale total and nothing appears to change (this was the root cause of fudged
  // resisted/hit rolls not updating damage).
  if (typeof roll._evaluateTotal === "function") roll._total = roll._evaluateTotal();
  else _recomputeTotalFallback(roll);

  if (typeof roll.resolveDamage === "function") {
    const actor = roll.actor ?? (roll.data?.actorId ? game.actors.get(roll.data.actorId) : null);
    const target = roll.data?.target ? fromUuidSync(roll.data.target) : null;
    if (actor && target) {
      try {
        roll.resolveDamage(actor, target);
      } catch (err) {
        console.warn("dice-fudger | resolveDamage() failed, falling back to a bare total recompute:", err);
      }
    } else {
      console.warn("dice-fudger | Attack roll has no resolvable actor/target - only the total was fixed. " +
        "The Hit/Miss badge and damage total on this card may not reflect the edit.");
    }
  }
}

class DiceFudger {
  /**
   * Arm a roll to be forced into the given outcome bracket the next time it happens. By default
   * this matches the very next qualifying roll (any Roll with `dc` in its data) from ANYONE - if
   * your table has other rolls likely to land first (other players, NPCs, damage rolls), pass
   * `actorId` to wait specifically for that actor's next qualifying roll instead, ignoring
   * everyone else's in the meantime. Callable directly from a macro, e.g.
   * `DiceFudger.armNextRoll("success")` or `DiceFudger.armNextRoll("success", {actorId: "..."})`.
   * @param {"criticalSuccess"|"success"|"failure"|"criticalFailure"} outcome
   * @param {object} [options]
   * @param {string|null} [options.actorId] Only fudge this actor's next qualifying roll
   */
  static armNextRoll(outcome, {actorId = null} = {}) {
    if (!game.user?.isGM) {
      ui.notifications.warn("Only the GM can fudge rolls.");
      return;
    }
    if (!(outcome in OUTCOME_LABELS)) {
      ui.notifications.error(`dice-fudger | Unknown outcome "${outcome}". Use one of: ${Object.keys(OUTCOME_LABELS).join(", ")}.`);
      return;
    }
    _installSingleRollRigging();
    _pendingSingleRollOutcome = {outcome, actorId: actorId || null};
    _updateArmedIndicator();
    const targetName = actorId ? (game.actors?.get(actorId)?.name ?? "the selected actor") : null;
    ui.notifications.info(`Dice Fudger: next ${targetName ? `roll from ${targetName}` : "roll"} will be forced to ${OUTCOME_LABELS[outcome]}.`);
  }

  /**
   * Open a small dialog to pick the outcome for the very next qualifying roll from ANYONE -
   * whoever rolls first is who gets fudged - or cancel an already-armed fudge. This is what the
   * auto-created "Fudge Next Roll (Anyone)" macro calls. Use promptArmNextRollForPlayer instead
   * if you want to wait specifically for one player's roll regardless of what anyone else rolls
   * in the meantime.
   * @returns {Promise<void>}
   */
  static async promptArmNextRoll() {
    if (!game.user?.isGM) {
      ui.notifications.warn("Only the GM can fudge rolls.");
      return;
    }
    const outcome = await new Promise((resolve) => {
      new Dialog({
        title: "Fudge Next Roll (Anyone)",
        content: "<p>Force the very next qualifying roll (skill check, save, attack, etc.) from anyone at the table to a specific outcome.</p>",
        buttons: {
          criticalSuccess: {label: "Critical Success", callback: () => resolve("criticalSuccess")},
          success: {label: "Success", callback: () => resolve("success")},
          failure: {label: "Failure", callback: () => resolve("failure")},
          criticalFailure: {label: "Critical Failure", callback: () => resolve("criticalFailure")},
          cancel: {label: "Cancel Armed Fudge", callback: () => resolve("__cancel__")}
        },
        default: "success",
        close: () => resolve(null)
      }).render(true);
    });
    if (outcome === "__cancel__") {
      _pendingSingleRollOutcome = null;
      _updateArmedIndicator();
      ui.notifications.info("Dice Fudger: next-roll fudge cancelled.");
      return;
    }
    if (outcome) DiceFudger.armNextRoll(outcome);
  }

  /**
   * Open a dialog to pick BOTH a specific player character and an outcome, and arm the fudge to
   * wait only for that actor's next qualifying roll - any other roll that happens in the
   * meantime (another player, an NPC, a damage roll) is ignored and left completely untouched,
   * and does not consume the arming. This is what the auto-created "Fudge Next Roll (Choose
   * Player)" macro calls.
   * @returns {Promise<void>}
   */
  static async promptArmNextRollForPlayer() {
    if (!game.user?.isGM) {
      ui.notifications.warn("Only the GM can fudge rolls.");
      return;
    }
    const actors = game.actors
      .filter((a) => a.hasPlayerOwner)
      .sort((a, b) => a.name.localeCompare(b.name));
    if (!actors.length) {
      ui.notifications.warn("Dice Fudger: no player-owned characters found to target.");
      return;
    }
    const actorOptions = actors.map((a) => `<option value="${a.id}">${a.name}</option>`).join("");
    const content = `
      <p>Force a specific player's next qualifying roll (skill check, save, attack, etc.) to a chosen outcome. Rolls from anyone else are ignored.</p>
      <div class="form-group">
        <label for="dice-fudger-target-actor">Player:</label>
        <select id="dice-fudger-target-actor" name="targetActor" autofocus>
          ${actorOptions}
        </select>
      </div>
    `;
    const readTarget = (html) => _toJQuery(html).find("#dice-fudger-target-actor").val() || null;
    const result = await new Promise((resolve) => {
      new Dialog({
        title: "Fudge Next Roll (Choose Player)",
        content,
        buttons: {
          criticalSuccess: {label: "Critical Success", callback: (html) => resolve({outcome: "criticalSuccess", actorId: readTarget(html)})},
          success: {label: "Success", callback: (html) => resolve({outcome: "success", actorId: readTarget(html)})},
          failure: {label: "Failure", callback: (html) => resolve({outcome: "failure", actorId: readTarget(html)})},
          criticalFailure: {label: "Critical Failure", callback: (html) => resolve({outcome: "criticalFailure", actorId: readTarget(html)})},
          cancel: {label: "Cancel Armed Fudge", callback: () => resolve("__cancel__")}
        },
        default: "success",
        close: () => resolve(null)
      }).render(true);
    });
    if (result === "__cancel__") {
      _pendingSingleRollOutcome = null;
      _updateArmedIndicator();
      ui.notifications.info("Dice Fudger: next-roll fudge cancelled.");
      return;
    }
    if (result) DiceFudger.armNextRoll(result.outcome, {actorId: result.actorId});
  }

  static async promptPreRollOutcome() {
    return new Promise((resolve) => {
      new Dialog({
        title: "Force Group Check Outcome",
        content: "<p>Apply a forced outcome to the next group check you configure?</p>",
        buttons: {
          criticalSuccess: {
            label: "Critical Success",
            callback: () => resolve("criticalSuccess")
          },
          success: {
            label: "Success",
            callback: () => resolve("success")
          },
          failure: {
            label: "Failure",
            callback: () => resolve("failure")
          },
          criticalFailure: {
            label: "Critical Failure",
            callback: () => resolve("criticalFailure")
          },
          none: {
            label: "None",
            callback: () => resolve(null)
          }
        },
        default: "none",
        close: () => resolve(null)
      }).render(true);
    });
  }

  /**
   * Open the fudge dialog for a chat message.
   * @param {ChatMessage} message
   */
  static async open(message) {
    const dice = _getEditableDice(message);
    if (!dice.length) {
      ui.notifications.warn("This message has no editable dice.");
      return;
    }

    const {NumberField} = foundry.data.fields;
    const content = document.createElement("div");
    content.innerHTML = `<p style="margin-bottom:0.5em;">
      Edit any die below, then Save. Nothing is re-rolled - you're directly setting the face
      value. The message stays hidden until you use Foundry's own "Reveal Message" option.
    </p>`;

    dice.forEach((d, i) => {
      const source = _describeRollSource(d.roll);
      const rollLabel = source ? `Roll ${d.rollIndex + 1} (${source})` : `Roll ${d.rollIndex + 1}`;
      const field = new NumberField({
        label: `${rollLabel} - die d${d.faces} (currently ${d.value})`,
        min: 1, max: d.faces, step: 1, integer: true, required: true
      });
      field.name = `die${i}`;
      content.append(field.toFormGroup({classes: ["slim"]}, {value: d.value, autofocus: i === 0}));
    });

    // Offer the same "Force Outcome" shortcuts as the chat-card buttons, right in the dialog,
    // for the same messages the chat card would show them on. These are wired as real DialogV2
    // buttons (not appended into `content` and wired by hand) so Foundry's own button/close
    // lifecycle handles them - clicking one always closes the dialog, which matters here: forcing
    // an outcome updates the message's rolls directly, but the die fields above were populated
    // from a snapshot taken before that; if the dialog stayed open and the GM then hit Save, the
    // stale field values would silently overwrite the just-forced result.
    const showForceButtons = game.settings.get(MODULE_ID, "showActionOutcomeButtons")
      && _isPendingActionMessage(message);

    let result;
    try {
      result = await foundry.applications.api.DialogV2.wait({
        window: {title: `Fudge Roll - ${message.speaker?.alias ?? "Chat Message"}`},
        content,
        buttons: [
          {
            action: "save",
            label: "Save",
            icon: "fa-solid fa-check",
            default: true,
            callback: (_event, button) => new foundry.applications.ux.FormDataExtended(button.form).object
          },
          ...(showForceButtons ? FORCE_OUTCOME_BUTTONS.map((b) => ({
            action: `force-${b.action}`,
            label: `Force ${b.label}`,
            callback: () => ({dice_fudger_force: b.action})
          })) : [])
        ]
      });
    } catch (err) {
      return; // cancelled
    }
    if (!result) return;
    if (result.dice_fudger_force) {
      await DiceFudger.forceActionOutcome(message, result.dice_fudger_force);
      return;
    }
    const formData = result;

    const touchedRolls = new Set();
    dice.forEach((d, i) => {
      const raw = formData[`die${i}`];
      const value = _clamp(Math.round(Number(raw)), 1, d.faces);
      if (value === d.value) return;
      d.term.results[d.dieIndex].result = value;
      touchedRolls.add(d.roll);
    });

    if (!touchedRolls.size) return; // nothing changed

    for (const roll of touchedRolls) await _reresolveRoll(roll);

    const tracker = {changed: false};
    let events = message.flags?.crucible?.events;
    for (const roll of touchedRolls) {
      events = _applyFudgedEventResources(events, message, roll, tracker);
    }

    const updateData = {rolls: message.rolls.map((roll) => typeof roll.toJSON === "function" ? roll.toJSON() : roll)};
    if (tracker.changed) updateData["flags.crucible.events"] = events;

    await message.update(updateData, {diff: false});
    ui.notifications.info("Roll fudged. Use Foundry's \"Reveal Message\" option when you're ready to show it.");
  }

  static async forceGroupOutcome(message, outcome, {silent = false} = {}) {
    console.debug("dice-fudger | forceGroupOutcome called", {messageId: message.id, outcome, rollCount: message.rolls?.length});
    const rolls = message.rolls ?? [];
    if (!rolls.length) {
      if (!silent) ui.notifications.warn("No participant rolls found for this message.");
      return false;
    }

    if (((outcome === "success") && (rolls.length < 3)) || ((outcome === "failure") && (rolls.length < 2))) {
      const msg = `A plain "${OUTCOME_LABELS[outcome] ?? outcome}" group result isn't reachable with only ${rolls.length} participant(s) under Crucible's own aggregate formula - the group card will read as critical instead, which is the closest achievable result.`;
      console.warn(`dice-fudger | ${msg}`);
      if (!silent) ui.notifications.warn(`Dice Fudger: ${msg}`);
    }
    const participantOutcomes = _computeParticipantOutcomes(outcome, rolls.length);
    const changedRolls = new Set();
    const rollsNeedingReresolve = new Set();
    let unresolvableCount = 0;
    rolls.forEach((roll, i) => {
      const rollOutcome = participantOutcomes[i] ?? outcome;
      const targetTotal = _chooseGroupOutcomeTotal(roll, rollOutcome);
      if (targetTotal === null) {
        unresolvableCount++;
        return;
      }
      const currentTotal = _evaluateRollTotal(roll);
      console.debug("dice-fudger | group outcome", {outcome, rollOutcome, targetTotal, currentTotal, roll});
      if (currentTotal === targetTotal) return;
      const edit = _assignDiceValuesToMatchTotal(roll, targetTotal);
      if (!edit.edited && roll._total !== targetTotal) {
        roll._total = targetTotal;
      }
      changedRolls.add(roll);
      if (edit.edited || typeof roll.resolveDamage === "function") {
        rollsNeedingReresolve.add(roll);
      }
    });

    if (unresolvableCount > 0) {
      const msg = `${unresolvableCount} of ${rolls.length} participant roll(s) had no dc/threshold data to force an outcome against and were left unmodified.`;
      console.warn(`dice-fudger | ${msg}`);
      if (!silent) ui.notifications.warn(`Dice Fudger: ${msg}`);
    }

    if (!changedRolls.size) {
      if (!silent) ui.notifications.info("Group outcome was already at the requested result.");
      return true;
    }

    for (const roll of rollsNeedingReresolve) {
      await _reresolveRoll(roll);
    }

    const tracker = {changed: false};
    let events = message.flags?.crucible?.events;
    for (const roll of rollsNeedingReresolve) {
      events = _applyFudgedEventResources(events, message, roll, tracker);
    }

    const updateData = {
      rolls: message.rolls.map((roll) => typeof roll.toJSON === "function" ? roll.toJSON() : roll)
    };
    if (tracker.changed) updateData["flags.crucible.events"] = events;
    let content = null;
    try {
      content = await _renderGroupCheckContent(message);
    } catch (err) {
      console.warn("dice-fudger | failed to render group check content, updating rolls only:", err);
    }
    if (typeof content === "string") updateData.content = content;
    await message.update(updateData, {diff: false});

    const label = {
      criticalSuccess: "Critical Success",
      success: "Success",
      failure: "Failure",
      criticalFailure: "Critical Failure"
    }[outcome] ?? "Outcome";
    ui.notifications.info(`Forced group outcome: ${label}.`);
  }

  /**
   * Force every roll on a pending (not-yet-confirmed) Crucible action-use card - e.g. a weapon
   * Strike, a cast spell's save - to a given outcome bracket. Unlike forceGroupOutcome, this does
   * not distribute participants across brackets (there's no group aggregate formula to satisfy
   * here) and it doesn't need to regenerate message.content: Crucible's action card, like its
   * other roll cards, reads success/failure and (for AttackRoll) the Hit/Miss badge and damage
   * total live off the roll data on every render, so fixing the roll (and, for AttackRoll,
   * re-running resolveDamage via _reresolveRoll) is all that's needed - the same as the base
   * "Fudge Roll" dialog. This does NOT click Confirm; the GM still does that manually once ready.
   * @param {ChatMessage} message
   * @param {string} outcome  "criticalSuccess"|"success"|"failure"|"criticalFailure"
   * @param {object} [options]
   * @param {boolean} [options.silent=false]
   * @returns {Promise<boolean>} false if there was nothing to force an outcome on
   */
  static async forceActionOutcome(message, outcome, {silent = false} = {}) {
    console.debug("dice-fudger | forceActionOutcome called", {messageId: message.id, outcome, rollCount: message.rolls?.length});
    const rolls = message.rolls ?? [];
    if (!rolls.length) {
      if (!silent) ui.notifications.warn("No rolls found on this action to force an outcome for.");
      return false;
    }

    const changedRolls = new Set();
    const rollsNeedingReresolve = new Set();
    let unresolvableCount = 0;
    for (const roll of rolls) {
      const targetTotal = _chooseGroupOutcomeTotal(roll, outcome);
      if (targetTotal === null) {
        unresolvableCount++;
        continue;
      }
      const currentTotal = _evaluateRollTotal(roll);
      if (currentTotal === targetTotal) continue;
      const edit = _assignDiceValuesToMatchTotal(roll, targetTotal);
      if (!edit.edited && roll._total !== targetTotal) roll._total = targetTotal;
      changedRolls.add(roll);
      if (edit.edited || typeof roll.resolveDamage === "function") rollsNeedingReresolve.add(roll);
    }

    if (unresolvableCount > 0) {
      const msg = `${unresolvableCount} of ${rolls.length} roll(s) on this action had no dc/threshold data to force an outcome against and were left unmodified.`;
      console.warn(`dice-fudger | ${msg}`);
      if (!silent) ui.notifications.warn(`Dice Fudger: ${msg}`);
    }

    if (!changedRolls.size) {
      if (!silent) ui.notifications.info("This action's outcome was already at the requested result.");
      return true;
    }

    for (const roll of rollsNeedingReresolve) {
      await _reresolveRoll(roll);
    }

    const tracker = {changed: false};
    let events = message.flags?.crucible?.events;
    for (const roll of rollsNeedingReresolve) {
      events = _applyFudgedEventResources(events, message, roll, tracker);
    }

    const updateData = {
      rolls: message.rolls.map((roll) => typeof roll.toJSON === "function" ? roll.toJSON() : roll)
    };
    if (tracker.changed) updateData["flags.crucible.events"] = events;
    await message.update(updateData, {diff: false});

    ui.notifications.info(`Forced action outcome: ${OUTCOME_LABELS[outcome] ?? outcome}.`);
    return true;
  }
}

globalThis.DiceFudger = DiceFudger;
